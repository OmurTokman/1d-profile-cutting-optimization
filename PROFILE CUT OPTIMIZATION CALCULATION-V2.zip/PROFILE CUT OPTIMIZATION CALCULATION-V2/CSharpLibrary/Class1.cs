﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;

namespace CSharpLibrary
{
    [ComVisible(true)]
    public class Class1
    {
        // Method to call from VBA, taking a string of numbers separated by commas, and a target range
        public string CallCSharpDLL(string numbers, int targetMin, int targetMax, out long totalCombinationsTried)
        {
            // Convert the string from VBA into an array of integers
            int[] numbersArray = Array.ConvertAll(numbers.Split(','), int.Parse);

            // Find the maximum combination for each target within the given range
            List<int> maxCombination = new List<int>();
            totalCombinationsTried = 0;
            for (int target = targetMin; target <= targetMax; target++)
            {
                List<int> combination = FindMaxCombination(numbersArray, target, ref totalCombinationsTried);
                if (combination != null && combination.Sum() > maxCombination.Sum())
                {
                    maxCombination = combination;
                }
            }

            // Return the maximum combination found
            if (maxCombination.Count > 0)
            {
                return $"{string.Join(" + ", maxCombination)}";
              
            }
            else
            {
                return "";
            }
        }

        // Method to find the maximum combination of numbers that sum up to the target
        private List<int> FindMaxCombination(int[] numbers, int target, ref long totalCombinationsTried)
        {
            List<int> maxCombination = new List<int>();
            int maxSum = int.MinValue;

            Array.Sort(numbers); // Sort the array in ascending order
            FindCombinationsHelper(numbers, target, 0, new List<int>(), ref maxCombination, ref maxSum, ref totalCombinationsTried);

            return maxCombination;
        }

        // Recursive helper method to find combinations
        private void FindCombinationsHelper(int[] numbers, int target, int index, List<int> current, ref List<int> maxCombination, ref int maxSum, ref long totalCombinationsTried)
        {
            totalCombinationsTried++;
            if (target == 0)
            {
                // Compare the current combination sum with the maximum sum found so far
                int sum = current.Sum();
                if (sum > maxSum)
                {
                    maxSum = sum;
                    maxCombination = new List<int>(current);
                }
                return;
            }

            for (int i = index; i < numbers.Length; i++)
            {
                if (i > index && numbers[i] == numbers[i - 1])
                {
                    // Skip the same number at the same index to avoid repetition
                    continue;
                }

                if (target - numbers[i] < 0)
                {
                    // Break if exceeding the target
                    break;
                }

                current.Add(numbers[i]);
                FindCombinationsHelper(numbers, target - numbers[i], i + 1, current, ref maxCombination, ref maxSum, ref  totalCombinationsTried); // Recursive call
                current.RemoveAt(current.Count - 1); // Backtracking
            }
        }
    }
}
